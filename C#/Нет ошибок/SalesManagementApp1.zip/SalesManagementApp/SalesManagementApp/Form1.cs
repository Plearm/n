﻿using System.Windows.Forms;
using System;
namespace SalesManagementApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnClients_Click(object sender, EventArgs e)
        {
            var clientsForm = new ClientsForm();
            clientsForm.ShowDialog();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            var productsForm = new ProductsForm();
            productsForm.ShowDialog();
        }

        private void btnContracts_Click(object sender, EventArgs e)
        {
            var contractsForm = new ContractsForm();
            contractsForm.ShowDialog();
        }

        private void btnContractDetails_Click(object sender, EventArgs e)
        {
            var contractDetailsForm = new ContractDetailsForm();
            contractDetailsForm.ShowDialog();
        }
    }
}

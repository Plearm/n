﻿using Npgsql;
using System.Data;
using System.Windows.Forms;
using System.Configuration;
using System;


public partial class ContractDetailsForm : Form
{
    private string connString = ConfigurationManager.ConnectionStrings["PostgresConnectionString"].ConnectionString;

    public ContractDetailsForm()
    {
        InitializeComponent();
        LoadContractDetails();
        LoadContracts();
        LoadProducts();
    }

    private void InitializeComponent()
    {
        this.dataGridViewContractDetails = new System.Windows.Forms.DataGridView();
        this.btnAdd = new System.Windows.Forms.Button();
        this.btnUpdate = new System.Windows.Forms.Button();
        this.btnDelete = new System.Windows.Forms.Button();
        this.cmbContracts = new System.Windows.Forms.ComboBox();
        this.cmbProducts = new System.Windows.Forms.ComboBox();
        this.txtQuantity = new System.Windows.Forms.TextBox();
        this.txtTotalAmount = new System.Windows.Forms.TextBox();
        this.SuspendLayout();
        // 
        // dataGridViewContractDetails
        // 
        this.dataGridViewContractDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridViewContractDetails.Location = new System.Drawing.Point(12, 12);
        this.dataGridViewContractDetails.Name = "dataGridViewContractDetails";
        this.dataGridViewContractDetails.Size = new System.Drawing.Size(760, 250);
        this.dataGridViewContractDetails.TabIndex = 0;
        // 
        // btnAdd
        // 
        this.btnAdd.Location = new System.Drawing.Point(12, 268);
        this.btnAdd.Name = "btnAdd";
        this.btnAdd.Size = new System.Drawing.Size(75, 23);
        this.btnAdd.TabIndex = 1;
        this.btnAdd.Text = "Добавить";
        this.btnAdd.UseVisualStyleBackColor = true;
        this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
        // 
        // btnUpdate
        // 
        this.btnUpdate.Location = new System.Drawing.Point(93, 268);
        this.btnUpdate.Name = "btnUpdate";
        this.btnUpdate.Size = new System.Drawing.Size(75, 23);
        this.btnUpdate.TabIndex = 2;
        this.btnUpdate.Text = "Изменить";
        this.btnUpdate.UseVisualStyleBackColor = true;
        this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
        // 
        // btnDelete
        // 
        this.btnDelete.Location = new System.Drawing.Point(174, 268);
        this.btnDelete.Name = "btnDelete";
        this.btnDelete.Size = new System.Drawing.Size(75, 23);
        this.btnDelete.TabIndex = 3;
        this.btnDelete.Text = "Удалить";
        this.btnDelete.UseVisualStyleBackColor = true;
        this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
        // 
        // cmbContracts
        // 
        this.cmbContracts.FormattingEnabled = true;
        this.cmbContracts.Location = new System.Drawing.Point(12, 297);
        this.cmbContracts.Name = "cmbContracts";
        this.cmbContracts.Size = new System.Drawing.Size(121, 21);
        this.cmbContracts.TabIndex = 4;
        // 
        // cmbProducts
        // 
        this.cmbProducts.FormattingEnabled = true;
        this.cmbProducts.Location = new System.Drawing.Point(139, 297);
        this.cmbProducts.Name = "cmbProducts";
        this.cmbProducts.Size = new System.Drawing.Size(121, 21);
        this.cmbProducts.TabIndex = 5;
        // 
        // txtQuantity
        // 
        this.txtQuantity.Location = new System.Drawing.Point(266, 297);
        this.txtQuantity.Name = "txtQuantity";
        this.txtQuantity.Size = new System.Drawing.Size(100, 20);
        this.txtQuantity.TabIndex = 6;
        // 
        // txtTotalAmount
        // 
        this.txtTotalAmount.Location = new System.Drawing.Point(372, 297);
        this.txtTotalAmount.Name = "txtTotalAmount";
        this.txtTotalAmount.Size = new System.Drawing.Size(100, 20);
        this.txtTotalAmount.TabIndex = 7;
        // 
        // ContractDetailsForm
        // 
        this.ClientSize = new System.Drawing.Size(784, 361);
        this.Controls.Add(this.txtTotalAmount);
        this.Controls.Add(this.txtQuantity);
        this.Controls.Add(this.cmbProducts);
        this.Controls.Add(this.cmbContracts);
        this.Controls.Add(this.btnDelete);
        this.Controls.Add(this.btnUpdate);
        this.Controls.Add(this.btnAdd);
        this.Controls.Add(this.dataGridViewContractDetails);
        this.Name = "ContractDetailsForm";
        this.Text = "Детали контрактов";
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.DataGridView dataGridViewContractDetails;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnUpdate;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.ComboBox cmbContracts;
    private System.Windows.Forms.ComboBox cmbProducts;
    private System.Windows.Forms.TextBox txtQuantity;
    private System.Windows.Forms.TextBox txtTotalAmount;

    private void LoadContractDetails()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT contract_detail_id, contract_id, product_id, quantity, total_amount FROM ContractDetails";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewContractDetails.DataSource = dt;
            }
        }
    }

    private void LoadContracts()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT contract_id, client_id FROM Contracts";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbContracts.DataSource = dt;
                cmbContracts.DisplayMember = "contract_id";
                cmbContracts.ValueMember = "contract_id";
            }
        }
    }

    private void LoadProducts()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT product_id, name FROM Products";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbProducts.DataSource = dt;
                cmbProducts.DisplayMember = "name";
                cmbProducts.ValueMember = "product_id";
            }
        }
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "INSERT INTO ContractDetails (contract_id, product_id, quantity, total_amount) VALUES (@contract_id, @product_id, @quantity, @total_amount)";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("contract_id", (int)cmbContracts.SelectedValue);
                cmd.Parameters.AddWithValue("product_id", (int)cmbProducts.SelectedValue);
                cmd.Parameters.AddWithValue("quantity", Convert.ToInt32(txtQuantity.Text));
                cmd.Parameters.AddWithValue("total_amount", Convert.ToDecimal(txtTotalAmount.Text));
                cmd.ExecuteNonQuery();
            }
        }
        LoadContractDetails();
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
        if (dataGridViewContractDetails.SelectedRows.Count > 0)
        {
            var contractDetailId = (int)dataGridViewContractDetails.SelectedRows[0].Cells["contract_detail_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "UPDATE ContractDetails SET contract_id = @contract_id, product_id = @product_id, quantity = @quantity, total_amount = @total_amount WHERE contract_detail_id = @contract_detail_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("contract_detail_id", contractDetailId);
                    cmd.Parameters.AddWithValue("contract_id", (int)cmbContracts.SelectedValue);
                    cmd.Parameters.AddWithValue("product_id", (int)cmbProducts.SelectedValue);
                    cmd.Parameters.AddWithValue("quantity", Convert.ToInt32(txtQuantity.Text));
                    cmd.Parameters.AddWithValue("total_amount", Convert.ToDecimal(txtTotalAmount.Text));
                    cmd.ExecuteNonQuery();
                }
            }
            LoadContractDetails();
        }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (dataGridViewContractDetails.SelectedRows.Count > 0)
        {
            var contractDetailId = (int)dataGridViewContractDetails.SelectedRows[0].Cells["contract_detail_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "DELETE FROM ContractDetails WHERE contract_detail_id = @contract_detail_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("contract_detail_id", contractDetailId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadContractDetails();
        }
    }
}

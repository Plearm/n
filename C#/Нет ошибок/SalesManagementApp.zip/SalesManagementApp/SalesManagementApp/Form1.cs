﻿using System.Windows.Forms;
using System;
public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void InitializeComponent()
    {
        this.btnClients = new System.Windows.Forms.Button();
        this.btnProducts = new System.Windows.Forms.Button();
        this.btnContracts = new System.Windows.Forms.Button();
        this.btnContractDetails = new System.Windows.Forms.Button();
        this.SuspendLayout();
        // 
        // btnClients
        // 
        this.btnClients.Location = new System.Drawing.Point(12, 12);
        this.btnClients.Name = "btnClients";
        this.btnClients.Size = new System.Drawing.Size(100, 23);
        this.btnClients.TabIndex = 0;
        this.btnClients.Text = "Клиенты";
        this.btnClients.UseVisualStyleBackColor = true;
        this.btnClients.Click += new System.EventHandler(this.btnClients_Click);
        // 
        // btnProducts
        // 
        this.btnProducts.Location = new System.Drawing.Point(12, 41);
        this.btnProducts.Name = "btnProducts";
        this.btnProducts.Size = new System.Drawing.Size(100, 23);
        this.btnProducts.TabIndex = 1;
        this.btnProducts.Text = "Товары";
        this.btnProducts.UseVisualStyleBackColor = true;
        this.btnProducts.Click += new System.EventHandler(this.btnProducts_Click);
        // 
        // btnContracts
        // 
        this.btnContracts.Location = new System.Drawing.Point(12, 70);
        this.btnContracts.Name = "btnContracts";
        this.btnContracts.Size = new System.Drawing.Size(100, 23);
        this.btnContracts.TabIndex = 2;
        this.btnContracts.Text = "Контракты";
        this.btnContracts.UseVisualStyleBackColor = true;
        this.btnContracts.Click += new System.EventHandler(this.btnContracts_Click);
        // 
        // btnContractDetails
        // 
        this.btnContractDetails.Location = new System.Drawing.Point(12, 99);
        this.btnContractDetails.Name = "btnContractDetails";
        this.btnContractDetails.Size = new System.Drawing.Size(100, 23);
        this.btnContractDetails.TabIndex = 3;
        this.btnContractDetails.Text = "Детали контрактов";
        this.btnContractDetails.UseVisualStyleBackColor = true;
        this.btnContractDetails.Click += new System.EventHandler(this.btnContractDetails_Click);
        // 
        // Form1
        // 
        this.ClientSize = new System.Drawing.Size(284, 261);
        this.Controls.Add(this.btnContractDetails);
        this.Controls.Add(this.btnContracts);
        this.Controls.Add(this.btnProducts);
        this.Controls.Add(this.btnClients);
        this.Name = "Form1";
        this.ResumeLayout(false);
    }

    private System.Windows.Forms.Button btnClients;
    private System.Windows.Forms.Button btnProducts;
    private System.Windows.Forms.Button btnContracts;
    private System.Windows.Forms.Button btnContractDetails;

    private void btnClients_Click(object sender, EventArgs e)
    {
        var clientsForm = new ClientsForm();
        clientsForm.ShowDialog();
    }

    private void btnProducts_Click(object sender, EventArgs e)
    {
        var productsForm = new ProductsForm();
        productsForm.ShowDialog();
    }

    private void btnContracts_Click(object sender, EventArgs e)
    {
        var contractsForm = new ContractsForm();
        contractsForm.ShowDialog();
    }

    private void btnContractDetails_Click(object sender, EventArgs e)
    {
        var contractDetailsForm = new ContractDetailsForm();
        contractDetailsForm.ShowDialog();
    }
}

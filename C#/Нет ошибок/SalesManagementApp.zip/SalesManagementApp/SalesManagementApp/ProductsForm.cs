﻿using Npgsql;
using System.Data;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;



public partial class ProductsForm : Form
{
    private string connString = ConfigurationManager.ConnectionStrings["PostgresConnectionString"].ConnectionString;

    public ProductsForm()
    {
        InitializeComponent();
        LoadProducts();
    }

    private void InitializeComponent()
    {
        this.dataGridViewProducts = new System.Windows.Forms.DataGridView();
        this.btnAdd = new System.Windows.Forms.Button();
        this.btnUpdate = new System.Windows.Forms.Button();
        this.btnDelete = new System.Windows.Forms.Button();
        this.txtName = new System.Windows.Forms.TextBox();
        this.txtPrice = new System.Windows.Forms.TextBox();
        this.SuspendLayout();
        // 
        // dataGridViewProducts
        // 
        this.dataGridViewProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridViewProducts.Location = new System.Drawing.Point(12, 12);
        this.dataGridViewProducts.Name = "dataGridViewProducts";
        this.dataGridViewProducts.Size = new System.Drawing.Size(760, 250);
        this.dataGridViewProducts.TabIndex = 0;
        // 
        // btnAdd
        // 
        this.btnAdd.Location = new System.Drawing.Point(12, 268);
        this.btnAdd.Name = "btnAdd";
        this.btnAdd.Size = new System.Drawing.Size(75, 23);
        this.btnAdd.TabIndex = 1;
        this.btnAdd.Text = "Добавить";
        this.btnAdd.UseVisualStyleBackColor = true;
        this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
        // 
        // btnUpdate
        // 
        this.btnUpdate.Location = new System.Drawing.Point(93, 268);
        this.btnUpdate.Name = "btnUpdate";
        this.btnUpdate.Size = new System.Drawing.Size(75, 23);
        this.btnUpdate.TabIndex = 2;
        this.btnUpdate.Text = "Изменить";
        this.btnUpdate.UseVisualStyleBackColor = true;
        this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
        // 
        // btnDelete
        // 
        this.btnDelete.Location = new System.Drawing.Point(174, 268);
        this.btnDelete.Name = "btnDelete";
        this.btnDelete.Size = new System.Drawing.Size(75, 23);
        this.btnDelete.TabIndex = 3;
        this.btnDelete.Text = "Удалить";
        this.btnDelete.UseVisualStyleBackColor = true;
        this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
        // 
        // txtName
        // 
        this.txtName.Location = new System.Drawing.Point(12, 297);
        this.txtName.Name = "txtName";
        this.txtName.Size = new System.Drawing.Size(237, 20);
        this.txtName.TabIndex = 4;
        // 
        // txtPrice
        // 
        this.txtPrice.Location = new System.Drawing.Point(255, 297);
        this.txtPrice.Name = "txtPrice";
        this.txtPrice.Size = new System.Drawing.Size(237, 20);
        this.txtPrice.TabIndex = 5;
        // 
        // ProductsForm
        // 
        this.ClientSize = new System.Drawing.Size(784, 361);
        this.Controls.Add(this.txtPrice);
        this.Controls.Add(this.txtName);
        this.Controls.Add(this.btnDelete);
        this.Controls.Add(this.btnUpdate);
        this.Controls.Add(this.btnAdd);
        this.Controls.Add(this.dataGridViewProducts);
        this.Name = "ProductsForm";
        this.Text = "Товары";
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.DataGridView dataGridViewProducts;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnUpdate;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.TextBox txtName;
    private System.Windows.Forms.TextBox txtPrice;

    private void LoadProducts()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT product_id, name, price FROM Products";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewProducts.DataSource = dt;
            }
        }
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "INSERT INTO Products (name, price) VALUES (@name, @price)";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("name", txtName.Text);
                cmd.Parameters.AddWithValue("price", Convert.ToDecimal(txtPrice.Text));
                cmd.ExecuteNonQuery();
            }
        }
        LoadProducts();
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
        if (dataGridViewProducts.SelectedRows.Count > 0)
        {
            var productId = (int)dataGridViewProducts.SelectedRows[0].Cells["product_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "UPDATE Products SET name = @name, price = @price WHERE product_id = @product_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("product_id", productId);
                    cmd.Parameters.AddWithValue("name", txtName.Text);
                    cmd.Parameters.AddWithValue("price", Convert.ToDecimal(txtPrice.Text));
                    cmd.ExecuteNonQuery();
                }
            }
            LoadProducts();
        }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (dataGridViewProducts.SelectedRows.Count > 0)
        {
            var productId = (int)dataGridViewProducts.SelectedRows[0].Cells["product_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "DELETE FROM Products WHERE product_id = @product_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("product_id", productId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadProducts();
        }
    }
}

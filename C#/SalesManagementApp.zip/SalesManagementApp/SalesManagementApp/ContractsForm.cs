﻿using Npgsql;
using System.Configuration;
using System.Data;
using System.Windows.Forms;
using System;


public partial class ContractsForm : Form
{
    private string connString = ConfigurationManager.ConnectionStrings["PostgresConnectionString"].ConnectionString;

    public ContractsForm()
    {
        InitializeComponent();
        LoadContracts();
        LoadClients();
    }

    private void InitializeComponent()
    {
        this.dataGridViewContracts = new System.Windows.Forms.DataGridView();
        this.btnAdd = new System.Windows.Forms.Button();
        this.btnUpdate = new System.Windows.Forms.Button();
        this.btnDelete = new System.Windows.Forms.Button();
        this.cmbClients = new System.Windows.Forms.ComboBox();
        this.dtpContractDate = new System.Windows.Forms.DateTimePicker();
        this.txtTotalAmount = new System.Windows.Forms.TextBox();
        this.cmbPaymentType = new System.Windows.Forms.ComboBox();
        this.chkPrepayment = new System.Windows.Forms.CheckBox();
        this.chkShipment = new System.Windows.Forms.CheckBox();
        this.SuspendLayout();
        // 
        // dataGridViewContracts
        // 
        this.dataGridViewContracts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridViewContracts.Location = new System.Drawing.Point(12, 12);
        this.dataGridViewContracts.Name = "dataGridViewContracts";
        this.dataGridViewContracts.Size = new System.Drawing.Size(760, 250);
        this.dataGridViewContracts.TabIndex = 0;
        // 
        // btnAdd
        // 
        this.btnAdd.Location = new System.Drawing.Point(12, 268);
        this.btnAdd.Name = "btnAdd";
        this.btnAdd.Size = new System.Drawing.Size(75, 23);
        this.btnAdd.TabIndex = 1;
        this.btnAdd.Text = "Добавить";
        this.btnAdd.UseVisualStyleBackColor = true;
        this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
        // 
        // btnUpdate
        // 
        this.btnUpdate.Location = new System.Drawing.Point(93, 268);
        this.btnUpdate.Name = "btnUpdate";
        this.btnUpdate.Size = new System.Drawing.Size(75, 23);
        this.btnUpdate.TabIndex = 2;
        this.btnUpdate.Text = "Изменить";
        this.btnUpdate.UseVisualStyleBackColor = true;
        this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
        // 
        // btnDelete
        // 
        this.btnDelete.Location = new System.Drawing.Point(174, 268);
        this.btnDelete.Name = "btnDelete";
        this.btnDelete.Size = new System.Drawing.Size(75, 23);
        this.btnDelete.TabIndex = 3;
        this.btnDelete.Text = "Удалить";
        this.btnDelete.UseVisualStyleBackColor = true;
        this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
        // 
        // cmbClients
        // 
        this.cmbClients.FormattingEnabled = true;
        this.cmbClients.Location = new System.Drawing.Point(12, 297);
        this.cmbClients.Name = "cmbClients";
        this.cmbClients.Size = new System.Drawing.Size(121, 21);
        this.cmbClients.TabIndex = 4;
        // 
        // dtpContractDate
        // 
        this.dtpContractDate.Location = new System.Drawing.Point(139, 297);
        this.dtpContractDate.Name = "dtpContractDate";
        this.dtpContractDate.Size = new System.Drawing.Size(200, 20);
        this.dtpContractDate.TabIndex = 5;
        // 
        // txtTotalAmount
        // 
        this.txtTotalAmount.Location = new System.Drawing.Point(345, 297);
        this.txtTotalAmount.Name = "txtTotalAmount";
        this.txtTotalAmount.Size = new System.Drawing.Size(100, 20);
        this.txtTotalAmount.TabIndex = 6;
        // 
        // cmbPaymentType
        // 
        this.cmbPaymentType.FormattingEnabled = true;
        this.cmbPaymentType.Items.AddRange(new object[] {
        "Наличные",
        "Безналичные"});
        this.cmbPaymentType.Location = new System.Drawing.Point(451, 297);
        this.cmbPaymentType.Name = "cmbPaymentType";
        this.cmbPaymentType.Size = new System.Drawing.Size(121, 21);
        this.cmbPaymentType.TabIndex = 7;
        // 
        // chkPrepayment
        // 
        this.chkPrepayment.AutoSize = true;
        this.chkPrepayment.Location = new System.Drawing.Point(578, 299);
        this.chkPrepayment.Name = "chkPrepayment";
        this.chkPrepayment.Size = new System.Drawing.Size(80, 17);
        this.chkPrepayment.TabIndex = 8;
        this.chkPrepayment.Text = "Предоплата";
        this.chkPrepayment.UseVisualStyleBackColor = true;
        // 
        // chkShipment
        // 
        this.chkShipment.AutoSize = true;
        this.chkShipment.Location = new System.Drawing.Point(664, 299);
        this.chkShipment.Name = "chkShipment";
        this.chkShipment.Size = new System.Drawing.Size(74, 17);
        this.chkShipment.TabIndex = 9;
        this.chkShipment.Text = "Отгрузка";
        this.chkShipment.UseVisualStyleBackColor = true;
        // 
        // ContractsForm
        // 
        this.ClientSize = new System.Drawing.Size(784, 361);
        this.Controls.Add(this.chkShipment);
        this.Controls.Add(this.chkPrepayment);
        this.Controls.Add(this.cmbPaymentType);
        this.Controls.Add(this.txtTotalAmount);
        this.Controls.Add(this.dtpContractDate);
        this.Controls.Add(this.cmbClients);
        this.Controls.Add(this.btnDelete);
        this.Controls.Add(this.btnUpdate);
        this.Controls.Add(this.btnAdd);
        this.Controls.Add(this.dataGridViewContracts);
        this.Name = "ContractsForm";
        this.Text = "Контракты";
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.DataGridView dataGridViewContracts;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnUpdate;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.ComboBox cmbClients;
    private System.Windows.Forms.DateTimePicker dtpContractDate;
    private System.Windows.Forms.TextBox txtTotalAmount;
    private System.Windows.Forms.ComboBox cmbPaymentType;
    private System.Windows.Forms.CheckBox chkPrepayment;
    private System.Windows.Forms.CheckBox chkShipment;

    private void LoadContracts()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT contract_id, client_id, contract_date, total_amount, payment_type, prepayment, shipment FROM Contracts";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewContracts.DataSource = dt;
            }
        }
    }

    private void LoadClients()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT client_id, name FROM Clients";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbClients.DataSource = dt;
                cmbClients.DisplayMember = "name";
                cmbClients.ValueMember = "client_id";
            }
        }
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "INSERT INTO Contracts (client_id, contract_date, total_amount, payment_type, prepayment, shipment) VALUES (@client_id, @contract_date, @total_amount, @payment_type, @prepayment, @shipment)";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("client_id", (int)cmbClients.SelectedValue);
                cmd.Parameters.AddWithValue("contract_date", dtpContractDate.Value);
                cmd.Parameters.AddWithValue("total_amount", Convert.ToDecimal(txtTotalAmount.Text));
                cmd.Parameters.AddWithValue("payment_type", cmbPaymentType.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("prepayment", chkPrepayment.Checked);
                cmd.Parameters.AddWithValue("shipment", chkShipment.Checked);
                cmd.ExecuteNonQuery();
            }
        }
        LoadContracts();
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
        if (dataGridViewContracts.SelectedRows.Count > 0)
        {
            var contractId = (int)dataGridViewContracts.SelectedRows[0].Cells["contract_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "UPDATE Contracts SET client_id = @client_id, contract_date = @contract_date, total_amount = @total_amount, payment_type = @payment_type, prepayment = @prepayment, shipment = @shipment WHERE contract_id = @contract_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("contract_id", contractId);
                    cmd.Parameters.AddWithValue("client_id", (int)cmbClients.SelectedValue);
                    cmd.Parameters.AddWithValue("contract_date", dtpContractDate.Value);
                    cmd.Parameters.AddWithValue("total_amount", Convert.ToDecimal(txtTotalAmount.Text));
                    cmd.Parameters.AddWithValue("payment_type", cmbPaymentType.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("prepayment", chkPrepayment.Checked);
                    cmd.Parameters.AddWithValue("shipment", chkShipment.Checked);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadContracts();
        }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (dataGridViewContracts.SelectedRows.Count > 0)
        {
            var contractId = (int)dataGridViewContracts.SelectedRows[0].Cells["contract_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "DELETE FROM Contracts WHERE contract_id = @contract_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("contract_id", contractId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadContracts();
        }
    }
}

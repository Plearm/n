﻿using Npgsql;
using System.Data;
using System.Windows.Forms;
using System;

public partial class ClientsForm : Form
{
    private string connString = ConfigurationManager.ConnectionStrings["PostgresConnectionString"].ConnectionString;

    public ClientsForm()
    {
        InitializeComponent();
        LoadClients();
    }

    private void InitializeComponent()
    {
        this.dataGridViewClients = new System.Windows.Forms.DataGridView();
        this.btnAdd = new System.Windows.Forms.Button();
        this.btnUpdate = new System.Windows.Forms.Button();
        this.btnDelete = new System.Windows.Forms.Button();
        this.txtName = new System.Windows.Forms.TextBox();
        this.txtContractInfo = new System.Windows.Forms.TextBox();
        this.SuspendLayout();
        // 
        // dataGridViewClients
        // 
        this.dataGridViewClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dataGridViewClients.Location = new System.Drawing.Point(12, 12);
        this.dataGridViewClients.Name = "dataGridViewClients";
        this.dataGridViewClients.Size = new System.Drawing.Size(760, 250);
        this.dataGridViewClients.TabIndex = 0;
        // 
        // btnAdd
        // 
        this.btnAdd.Location = new System.Drawing.Point(12, 268);
        this.btnAdd.Name = "btnAdd";
        this.btnAdd.Size = new System.Drawing.Size(75, 23);
        this.btnAdd.TabIndex = 1;
        this.btnAdd.Text = "Добавить";
        this.btnAdd.UseVisualStyleBackColor = true;
        this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
        // 
        // btnUpdate
        // 
        this.btnUpdate.Location = new System.Drawing.Point(93, 268);
        this.btnUpdate.Name = "btnUpdate";
        this.btnUpdate.Size = new System.Drawing.Size(75, 23);
        this.btnUpdate.TabIndex = 2;
        this.btnUpdate.Text = "Изменить";
        this.btnUpdate.UseVisualStyleBackColor = true;
        this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
        // 
        // btnDelete
        // 
        this.btnDelete.Location = new System.Drawing.Point(174, 268);
        this.btnDelete.Name = "btnDelete";
        this.btnDelete.Size = new System.Drawing.Size(75, 23);
        this.btnDelete.TabIndex = 3;
        this.btnDelete.Text = "Удалить";
        this.btnDelete.UseVisualStyleBackColor = true;
        this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
        // 
        // txtName
        // 
        this.txtName.Location = new System.Drawing.Point(12, 297);
        this.txtName.Name = "txtName";
        this.txtName.Size = new System.Drawing.Size(237, 20);
        this.txtName.TabIndex = 4;
        // 
        // txtContractInfo
        // 
        this.txtContractInfo.Location = new System.Drawing.Point(255, 297);
        this.txtContractInfo.Name = "txtContractInfo";
        this.txtContractInfo.Size = new System.Drawing.Size(237, 20);
        this.txtContractInfo.TabIndex = 5;
        // 
        // ClientsForm
        // 
        this.ClientSize = new System.Drawing.Size(784, 361);
        this.Controls.Add(this.txtContractInfo);
        this.Controls.Add(this.txtName);
        this.Controls.Add(this.btnDelete);
        this.Controls.Add(this.btnUpdate);
        this.Controls.Add(this.btnAdd);
        this.Controls.Add(this.dataGridViewClients);
        this.Name = "ClientsForm";
        this.Text = "Клиенты";
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.DataGridView dataGridViewClients;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnUpdate;
    private System.Windows.Forms.Button btnDelete;
    private System.Windows.Forms.TextBox txtName;
    private System.Windows.Forms.TextBox txtContractInfo;

    private void LoadClients()
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "SELECT client_id, name, contract_info FROM Clients";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewClients.DataSource = dt;
            }
        }
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        using (var conn = new NpgsqlConnection(connString))
        {
            conn.Open();
            var query = "INSERT INTO Clients (name, contract_info) VALUES (@name, @contract_info)";
            using (var cmd = new NpgsqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("name", txtName.Text);
                cmd.Parameters.AddWithValue("contract_info", txtContractInfo.Text);
                cmd.ExecuteNonQuery();
            }
        }
        LoadClients();
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
        if (dataGridViewClients.SelectedRows.Count > 0)
        {
            var clientId = (int)dataGridViewClients.SelectedRows[0].Cells["client_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "UPDATE Clients SET name = @name, contract_info = @contract_info WHERE client_id = @client_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("client_id", clientId);
                    cmd.Parameters.AddWithValue("name", txtName.Text);
                    cmd.Parameters.AddWithValue("contract_info", txtContractInfo.Text);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadClients();
        }
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (dataGridViewClients.SelectedRows.Count > 0)
        {
            var clientId = (int)dataGridViewClients.SelectedRows[0].Cells["client_id"].Value;
            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                var query = "DELETE FROM Clients WHERE client_id = @client_id";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("client_id", clientId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadClients();
        }
    }
}

using Microsoft.Office.Interop.Excel

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public class User
        {
            public string fio, address, pol, section;
            public User(string fio,string address, string pol,string[] section)
            {
                this.fio = fio;
                this.address = address;
                this.pol = pol;
                this.section = section;
            }
        }
        string text;
        List<User> users;

        public Form1()
        {
            users = new List<User>();
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.AppendText(text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string text = "";
            string fio = "";
            string address = "";
            string pol = "";
            string[] section = new string[checkedListBox1.CheckedItems.Count];
            for (int i = 0;i < section.Length; i++)
            {
                section[i] = (string)checkedListBox1.CheckedItems[i];
            }
            text += "���: " + textBox1.Text.ToString() + "\n";
            fio = textBox1.Text.ToString();
            text += "�����: " + comboBox1.Items[comboBox1.SelectedIndex].ToString() + "\n";
            address = comboBox1.Items[comboBox1.SelectedIndex].ToString();
            if (radioButton1.Checked)
            {
                text += "���: ������� \n";
                pol = "male";
            }
            if (radioButton2.Checked)
            {
                text += "���: ������� \n";
                pol = "female";
            }
            
            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
            {
                text += checkedListBox1.CheckedItems[i].ToString() + "\n";
            }

            richTextBox1.AppendText(text);
            MessageBox.Show("���������� �������� � ���������!");
            
            User u = new User(fio, address, pol,section);
            users.Add(u);
        }


        //private void excelButton_Click(object sender, EventArgs e)
        //{
        //    OpenFileDialog ofd = new OpenFileDialog();
        //    ofd.ShowDialog();
        //    String filename = ofd.FileName;

        //    Microsoft.Office.Interop.Excel.Application excelObj = new Microsoft.Office.Interop.Excel.Application();
        //    Microsoft.Office.InteropExcel.Application();
        //    excelObj.Visible = true;

        //    Workbook wb = excelObj.WorkBooks.Open(filename, 0, false, 5, "", "", false, XIPlatform.xlWindows, "", true, false, 0, false, false);
        //    WorkSheet wsh = wb.Sheets[];

        //    wsh.Cells[1, 1] = fio;
        //    wsh.Cells[1, 2] = adress;
        //    // ...
        //    wb.Sace();
        //    wb.Close();
        //}




        // ���� (30.03.24)
        // pgAdmin 4


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}